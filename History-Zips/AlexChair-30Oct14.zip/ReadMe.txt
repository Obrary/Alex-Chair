Product: Alex Chair, version 1.0, August 2014
Designer: Alex Zhang, alex.ming.zhang@gmail.com
Support:  support@obrary.com
Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The Alex Chair is designed to be printed on a CNC router.  A 1/4" end mill bit should be used on 1/2" plywood.

Files included in this package:
 - *.slvs - this is the 3D model in SolveSpace.  SolveSpace is a free app and can be found at http://solvespace.com/index.pl
 - *.dxf - this is the 2D plans of the Alex chair that can be opened in a variety of applications
 - ReadMe.txt - this file